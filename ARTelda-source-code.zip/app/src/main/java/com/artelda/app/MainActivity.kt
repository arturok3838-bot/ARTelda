package com.artelda.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.luaj.vm2.Globals
import org.luaj.vm2.LuaValue
import org.luaj.vm2.lib.VarArgFunction
import org.luaj.vm2.lib.jse.JsePlatform
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

private val BG = Color(0xFF100D19)
private val CARD = Color(0xFF211B30)
private val PURPLE = Color(0xFF9565FF)
private val ORANGE = Color(0xFFD97757)
private val MUTED = Color(0xFFA7A0B8)
private const val ACCESS_KEY = "WASP-DAN"
private const val ROBLOX_LABEL = "2.747.1486"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ARTeldaApp() }
    }
}

@Composable
private fun ARTeldaApp() {
    var authorized by remember { mutableStateOf(false) }
    var key by remember { mutableStateOf("") }
    var keyError by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Editor") }
    var source by remember {
        mutableStateOf("-- ARTelda Lua workspace\nprint('Welcome to ARTelda!')")
    }
    var console by remember { mutableStateOf("Console ready.") }
    var running by remember { mutableStateOf(false) }
    var scripts by remember { mutableStateOf(listOf("Main.lua")) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        background = BG, surface = CARD, primary = PURPLE,
        secondary = ORANGE, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = BG) {
            if (!authorized) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("ARTelda", color = ORANGE, fontSize = 44.sp, fontWeight = FontWeight.Black)
                    Text("LUA SCRIPT LAB", color = MUTED, fontSize = 12.sp)
                    Spacer(Modifier.height(28.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = CARD)) {
                        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("ACCESS KEY", color = MUTED, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(
                                value = key, onValueChange = { key = it; keyError = "" },
                                label = { Text("Enter key") },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true
                            )
                            if (keyError.isNotBlank()) Text(keyError, color = Color.Red)
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    if (key == ACCESS_KEY) authorized = true
                                    else keyError = "Invalid key"
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("UNLOCK") }
                            Text("WASP-DAN EDITION", color = MUTED, fontSize = 11.sp)
                        }
                    }
                }
            } else {
                Column(Modifier.fillMaxSize().padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("ARTelda", color = ORANGE, fontSize = 28.sp, fontWeight = FontWeight.Black)
                            Text("SCRIPT LAB  •  v1.0", color = MUTED, fontSize = 10.sp)
                        }
                        Text("● READY", color = Color(0xFF65D69A), fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("Editor", "Scripts", "Settings").forEach { item ->
                            FilterChip(
                                selected = tab == item,
                                onClick = { tab = item },
                                label = { Text(item) }
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    when (tab) {
                        "Editor" -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("main.lua", Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold)
                                Text("LUA", color = MUTED, fontSize = 11.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                            Card(
                                Modifier.weight(1f).fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = CARD),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                TextField(
                                    value = source, onValueChange = { source = it },
                                    modifier = Modifier.fillMaxSize(),
                                    textStyle = LocalTextStyle.current.copy(
                                        color = Color(0xFFE6DDFB), fontSize = 13.sp
                                    ),
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = CARD,
                                        unfocusedContainerColor = CARD,
                                        focusedIndicatorColor = Color.Transparent,
                                        unfocusedIndicatorColor = Color.Transparent
                                    )
                                )
                            }
                            Spacer(Modifier.height(9.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    enabled = !running,
                                    onClick = {
                                        running = true
                                        console = "Executing in standalone Lua sandbox..."
                                        scope.launch {
                                            console = withContext(Dispatchers.IO) { executeLua(source) }
                                            running = false
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text(if (running) "RUNNING..." else "▶ RUN") }
                                OutlinedButton(onClick = { source = ""; console = "Editor cleared." }) {
                                    Text("CLEAR")
                                }
                            }
                            Spacer(Modifier.height(9.dp))
                            Text("CONSOLE", color = MUTED, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Card(
                                Modifier.fillMaxWidth().heightIn(min = 75.dp, max = 125.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF09080E))
                            ) {
                                Text(
                                    console, Modifier.padding(12.dp).verticalScroll(rememberScrollState()),
                                    color = Color(0xFF9BE7B1), fontSize = 12.sp
                                )
                            }
                        }
                        "Scripts" -> {
                            Text("SAVED SCRIPTS", color = MUTED, fontSize = 11.sp)
                            Spacer(Modifier.height(8.dp))
                            scripts.forEach { name ->
                                Card(
                                    Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                        .clickable { source = "-- $name\nprint('Loaded $name')" },
                                    colors = CardDefaults.cardColors(containerColor = CARD)
                                ) {
                                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("◈", color = ORANGE)
                                        Spacer(Modifier.width(10.dp))
                                        Text(name, Modifier.weight(1f))
                                        Text("LOAD", color = PURPLE, fontSize = 11.sp)
                                    }
                                }
                            }
                            Button(onClick = {
                                scripts = scripts + "Script ${scripts.size + 1}.lua"
                            }) { Text("+ ADD SAMPLE") }
                            Text("Starter list is held in memory; file import/export is not included yet.", color = MUTED, fontSize = 12.sp)
                        }
                        else -> {
                            Card(colors = CardDefaults.cardColors(containerColor = CARD)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("ARTelda Settings", color = ORANGE, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(10.dp))
                                    Text("Access edition: WASP-DAN")
                                    Text("Target version label: Roblox $ROBLOX_LABEL")
                                    Text("Runtime: LuaJ, standalone sandbox")
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        "This app does not attach to Roblox, inject code into its client, or bypass anti-cheat.",
                                        color = MUTED, fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun executeLua(code: String): String {
    if (code.length > 20000) return "Error: script exceeds 20,000 characters."
    val executor = Executors.newSingleThreadExecutor { task ->
        Thread(task, "artelda-lua").apply { isDaemon = true }
    }
    return try {
        val output = StringBuilder()
        val future = executor.submit<String> {
            val globals: Globals = JsePlatform.standardGlobals()
            globals.set("os", LuaValue.NIL)
            globals.set("io", LuaValue.NIL)
            globals.set("package", LuaValue.NIL)
            globals.set("luajava", LuaValue.NIL)
            globals.set("print", object : VarArgFunction() {
                override fun invoke(args: org.luaj.vm2.Varargs): org.luaj.vm2.Varargs {
                    if (output.length < 8000) {
                        output.append((1..args.narg()).joinToString(" ") {
                            args.arg(it).tojstring()
                        }).append('\n')
                    }
                    return LuaValue.NONE
                }
            })
            globals.load(code, "main.lua").call()
            output.toString().ifBlank { "Executed successfully. No print output." }
        }
        future.get(2, TimeUnit.SECONDS)
    } catch (e: Exception) {
        "Lua error: ${e.cause?.message ?: e.message ?: "unknown error"}"
    } finally {
        executor.shutdownNow()
    }
}
