# ARTelda

Android Kotlin + Jetpack Compose starter for a standalone Lua editor.

- Access key demo gate: `WASP-DAN`
- LuaJ sandbox editor and console
- Scripts demo tab
- Settings and Roblox version label `2.747.1486`
- GitHub Actions APK build

This app is a standalone Lua environment. It does not inject into Roblox, attach to the Roblox process, modify the client, or bypass anti-cheat. The access key is hardcoded for demonstration and is recoverable from the APK; do not use it as secure authentication.

Upload the repository to GitHub, open Actions, run **Build ARTelda APK**, then download the `ARTelda-debug-apk` artifact.
